import socket
import threading

# Proxy server details
proxy_host = 'localhost'
proxy_port = 55555

# POP3 server details
pop3_server = 'localhost'
pop3_port = 110
real_username = 'katnicole'
real_password = 'katnicole14'

# Authentication details for proxy users
proxy_users = {
    'user1@example.com': 'password1',
    'user2@example.com': 'password2',
    'user3@example.com': 'password3'
}

def handle_client(client_socket):
    pop_conn = None
    try:
        # Connect to the real POP3 server
        pop_conn = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        pop_conn.connect((pop3_server, pop3_port))
        client_socket.send(pop_conn.recv(1024))  # Welcome message from the real server

        # Authenticate client to proxy
        client_socket.send(b'+OK Proxy POP3 server ready\r\n')
        user_authenticated = False

        while not user_authenticated:
            user_cmd = client_socket.recv(1024).decode().strip()
            if user_cmd.startswith('USER'):
                proxy_username = user_cmd.split()[1]
                client_socket.send(b'+OK User accepted\r\n')
            elif user_cmd.startswith('PASS'):
                proxy_password = user_cmd.split()[1]
                if proxy_users.get(proxy_username) == proxy_password:
                    user_authenticated = True
                    client_socket.send(b'+OK Proxy authentication successful\r\n')
                else:
                    client_socket.send(b'-ERR Invalid credentials\r\n')

        # Authenticate to the real POP3 server
        pop_conn.sendall(b'USER ' + bytes(real_username, 'utf-8') + b'\r\n')
        client_socket.send(pop_conn.recv(1024))
        pop_conn.sendall(b'PASS ' + bytes(real_password, 'utf-8') + b'\r\n')
        client_socket.send(pop_conn.recv(1024))

        # Relay messages between client and server
        while True:
            command = client_socket.recv(1024)
            if not command:
                break
            pop_conn.sendall(command)
            response = pop_conn.recv(1024)
            client_socket.send(response)

    except Exception as e:
        print(f"Error: {e}")
    finally:
        if client_socket:
            client_socket.close()
        if pop_conn:
            pop_conn.close()

def start_proxy():
    proxy_server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    proxy_server.bind((proxy_host, proxy_port))
    proxy_server.listen(5)
    print(f"Proxy server listening on {proxy_host}:{proxy_port}")

    while True:
        client_socket, addr = proxy_server.accept()
        print(f"Accepted connection from {addr}")
        client_handler = threading.Thread(target=handle_client, args=(client_socket,))
        client_handler.start()

if __name__ == "__main__":
    start_proxy()
