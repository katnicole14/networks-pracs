import socket
import threading
import ssl

# Proxy server configuration
PROXY_HOST = 'localhost'
PROXY_PORT = 55555
REAL_POP3_SERVER = 'pop.gmail.com'
REAL_POP3_PORT = 995 
PROXY_USERNAME = 'u22543946@tuks.co.za'
PROXY_PASSWORD = 'mxcjoptjkqmolevp'

# Function to handle client requests in the proxy server
def handle_client(client_socket):
    # Authentication
    client_socket.send(b'Username:')
    print("Please enter your username.")
    username = client_socket.recv(1024).decode().strip()
    client_socket.send(b'Password:')
    print("Please enter your password.")
    password = client_socket.recv(1024).decode().strip()

    if username == PROXY_USERNAME and password == PROXY_PASSWORD:
        # Authentication successful
        client_socket.send(b'Authentication successful.\n')
        print("Authentication successful. You can now send commands.")
        print("Type your command and press Enter to send.")
        print("For example: LIST, RETR 1, DELE 2, etc.")
        print("Type 'QUIT' to exit.")

        # Connect to real POP3 server
        print(f"Connecting to real POP3 server at {REAL_POP3_SERVER}:{REAL_POP3_PORT}...")
        real_pop3_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        real_pop3_socket = ssl.wrap_socket(real_pop3_socket, ssl_version=ssl.PROTOCOL_TLS)
        real_pop3_socket.connect((REAL_POP3_SERVER, REAL_POP3_PORT))
        print("Connected to real POP3 server.")

        # Relay messages between client and real POP3 server
        while True:
            # Prompt the client to type a command
            print(">> ", end="", flush=True)
            client_data = input().encode()
            if client_data.upper() == b'QUIT':
                break

            # Send the command to the real POP3 server
            real_pop3_socket.send(client_data)

            # Receive response from the real POP3 server
            real_pop3_response = real_pop3_socket.recv(1024)

            # Send response back to the client
            client_socket.send(real_pop3_response)

        # Close connections
        real_pop3_socket.close()
        client_socket.close()
        print("Disconnected.")
    else:
        # Authentication failed
        client_socket.send(b'Authentication failed.\n')
        client_socket.close()

# Function to start the proxy server
def start_proxy():
    # Create proxy server socket
    proxy_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    proxy_socket.bind((PROXY_HOST, PROXY_PORT))
    proxy_socket.listen(5)
    print(f"Proxy server listening on {PROXY_HOST}:{PROXY_PORT}")

    while True:
        # Accept client connection
        client_socket, client_address = proxy_socket.accept()
        print(f"Accepted connection from {client_address}")

        # Handle client request in a separate thread
        client_thread = threading.Thread(target=handle_client, args=(client_socket,))
        client_thread.start()

# Function to interact with the proxy server as a client
def interact_with_proxy():
    # Connect to proxy server
    proxy_client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    proxy_client.connect((PROXY_HOST, PROXY_PORT))
    print("Connected to proxy server.")

    # Receive authentication prompts
    print(proxy_client.recv(1024).decode())  # Username prompt
    proxy_client.send(input("Enter your username: ").encode())
    print(proxy_client.recv(1024).decode())  # Password prompt
    proxy_client.send(input("Enter your password: ").encode())

    # Receive authentication result
    auth_result = proxy_client.recv(1024).decode()
    print(auth_result)

    if "successful" in auth_result:
        print("Authentication successful. You can now send commands.")
        print("Type your command and press Enter to send.")
        print("For example: LIST, RETR 1, DELE 2, etc.")
        print("Type 'QUIT' to exit.")

        # Relay messages between client and proxy server
        while True:
            # Prompt the user to enter a command
            print(">> ", end="", flush=True)
            command = input().encode()

            # Send command to proxy server
            proxy_client.send(command)

            # Receive response from proxy server
            response = proxy_client.recv(1024).decode()
            print(response)

            if command.upper() == b'QUIT':
                break

        # Close connection
        proxy_client.close()
        print("Disconnected from proxy server.")
    else:
        print("Authentication failed.")
        proxy_client.close()

# Main function
if __name__ == "__main__":
    # Start proxy server in a separate thread
    proxy_thread = threading.Thread(target=start_proxy)
    proxy_thread.start()

    # Call the function to interact with the proxy server as a client
    interact_with_proxy()
